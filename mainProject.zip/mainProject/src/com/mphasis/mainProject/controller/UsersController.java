package com.mphasis.mainProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.mainProject.bean.Usersbean;
import com.mphasis.mainProject.model.Users;
import com.mphasis.mainProject.service.UsersService;

@Controller
public class UsersController {

	@Autowired
	private UsersService usersservice;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute("command") Usersbean UsersBean, 
			BindingResult result) {
		Users user = prepareModel(UsersBean);
		usersservice.addUsers(user);
		return new ModelAndView("redirect:/Register.jsp");
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}

	private Users prepareModel(Usersbean usersBean) {
		// TODO Auto-generated method stub
		Users user = new Users();
		user.setFirstname(Usersbean.getFirstname());
		//employee.setEmpAddress(employeeBean.getAddress());
		user.setLastname(Usersbean.getLastname());
		user.setUsername(Usersbean.getUsername());
		user.setEmail(Usersbean.getEmail());
		user.setPassword(Usersbean.getPassword());
		user.setConfirmpass(Usersbean.getConfirmpass());
		
		return null;
	}
}
