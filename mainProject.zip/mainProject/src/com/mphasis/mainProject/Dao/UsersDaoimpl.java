package com.mphasis.mainProject.Dao;


import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.mphasis.mainProject.model.Users;



@Repository("UsersDao")
public class UsersDaoimpl implements UsersDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addUsers(Users users) {
	  sessionFactory.getCurrentSession().save(users);
		//sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	
	
}
