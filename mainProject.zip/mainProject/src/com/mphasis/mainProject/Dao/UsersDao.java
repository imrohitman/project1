package com.mphasis.mainProject.Dao;

import com.mphasis.mainProject.model.Users;

public interface UsersDao {
	public void addUsers(Users user);

	
}
