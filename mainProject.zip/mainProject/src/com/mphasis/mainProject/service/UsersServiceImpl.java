package com.mphasis.mainProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.mphasis.mainProject.Dao.UsersDao;
import com.mphasis.mainProject.model.Users;

@Service("UsersService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)

public class UsersServiceImpl implements UsersService {
	@Autowired
	private UsersDao usersDao;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUser(Users user) {
		usersDao.addUsers(user);
	}

	@Override
	public void addUsers(Users user) {
		// TODO Auto-generated method stub
		
	}
}
