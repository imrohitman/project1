package com.mphasis.mainProject.service;

import com.mphasis.mainProject.model.Users;

public interface UsersService {
	public void addUsers(Users user);
}
