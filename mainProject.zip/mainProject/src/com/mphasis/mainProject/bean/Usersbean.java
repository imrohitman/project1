package com.mphasis.mainProject.bean;

public class Usersbean {
	private static String firstname;
	private static String lastname;
	private static String username;
	private static String email;
	private static String password;
	private static String confirmpass;
	public Usersbean(String firstname, String lastname, String username, String email, String password,
			String confirmpass) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.email = email;
		this.password = password;
		this.confirmpass = confirmpass;
	}
	public static String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public static String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public static String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public static String getEmail() {
		return email;
	}
	public void setEmailname(String email) {
		this.email = email;
	}
	public static String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public static String getConfirmpass() {
		return confirmpass;
	}
	public void setConfirmpass(String confirmpass) {
		this.confirmpass = confirmpass;
	}
	
}
