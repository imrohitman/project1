package com.mphasis.demoproject.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="exam175")
public class Exam {

	private String examName;
	@Id
	private int examId;
	private int noofQuestions;
	private int passMark;
	private String examDiscription;
	private double price;
	public int duration;
	public String getExamName() {
		return examName;
	}
	public void setExamName(String examName) {
		this.examName = examName;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public int getNoofQuestions() {
		return noofQuestions;
	}
	public void setNoofQuestions(int noofQuestions) {
		this.noofQuestions = noofQuestions;
	}
	public int getPassMark() {
		return passMark;
	}
	public void setPassMark(int passMark) {
		this.passMark = passMark;
	}
	public String getExamDiscription() {
		return examDiscription;
	}
	public void setExamDiscription(String examDiscription) {
		this.examDiscription = examDiscription;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public Exam(String examName, int examId, int noofQuestions, int passMark, String examDiscription, double price,
			int duration) {
		super();
		this.examName = examName;
		this.examId = examId;
		this.noofQuestions = noofQuestions;
		this.passMark = passMark;
		this.examDiscription = examDiscription;
		this.price = price;
		this.duration = duration;
	}
	public Exam() {
		super();
	}
	@Override
	public String toString() {
		return "Exam examName=" + examName + ", examId=" + examId + ", noofQuestions=" + noofQuestions + ", passMark="
				+ passMark + ", examDiscription=" + examDiscription + ", price=" + price + ", duration=" + duration;
	}
	
	
}
