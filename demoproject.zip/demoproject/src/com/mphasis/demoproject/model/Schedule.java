package com.mphasis.demoproject.model;

import java.time.LocalDate;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Schedule {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int scheduleId;
	
	private int examId;
	private String mobile;
	private LocalDate dateOfBooking;
	private LocalDate dateOfSchedule;
	private String paymentType;
	private String transactionNo;
	private String status;
	private int grade;
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public LocalDate getDateOfBooking() {
		return dateOfBooking;
	}
	public void setDateOfBooking(LocalDate dateOfBooking) {
		this.dateOfBooking = dateOfBooking;
	}
	public LocalDate getDateOfSchedule() {
		return dateOfSchedule;
	}
	public void setDateOfSchedule(LocalDate dateOfSchedule) {
		this.dateOfSchedule = dateOfSchedule;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Schedule(int scheduleId, int examId, String mobile, LocalDate dateOfBooking, LocalDate dateOfSchedule,
			String paymentType, String transactionNo, String status,int grade) {
		super();
		this.scheduleId = scheduleId;
		this.examId = examId;
		this.mobile = mobile;
		this.dateOfBooking = dateOfBooking;
		this.dateOfSchedule = dateOfSchedule;
		this.paymentType = paymentType;
		this.transactionNo = transactionNo;
		this.status = status;
		this.grade=grade;
	}
	public Schedule() {
		super();
	}
	@Override
	public String toString() {
		return "ScheduleId=" + scheduleId + ", examId=" + examId + ", mobile=" + mobile + ", dateOfBooking="
				+ dateOfBooking + ", dateOfSchedule=" + dateOfSchedule + ", paymentType=" + paymentType
				+ ", transactionNo=" + transactionNo + ", status=" + status+", Grade= "+grade ;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	

}
