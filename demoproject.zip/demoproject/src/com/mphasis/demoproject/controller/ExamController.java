package com.mphasis.demoproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

import com.mphasis.demoproject.bo.ExamBo;
import com.mphasis.demoproject.model.Exam;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ExamController {
	
	@Autowired
	ExamBo eb;
	

	
	
	@RequestMapping(value="/getallexamsdetails", produces= "application/json")
	public List<Exam> getViewExams(){
		return eb.getAllExams();
	}
	@RequestMapping(value="/getexam",produces="application/json")
	public Exam getExam(@RequestParam String id) {
		return eb.getExamById(Integer.parseInt(id));
	}
	@PostMapping
	public ResponseEntity<?> createExam(@Valid @RequestBody Exam e, UriComponentsBuilder ucBuilder){
		eb.insertExam(e);
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<>(headers, HttpStatus.CREATED);
	}

	@PostMapping(value="/createexam")
	public Exam createExam1(@Valid @RequestBody Exam e) {
	
		eb.insertExam(e);
		
		return e;
	}
	@PostMapping("createexam1")
	public Exam createExam112(@Valid @RequestBody Exam e) {
	
		eb.insertExam(e);
		
		return e;
	}
	 
	
	
	
	@RequestMapping("/addexamdetails")
	public ModelAndView addExamMethod() {
		return new ModelAndView("addexamdetails");
	}
	


}
