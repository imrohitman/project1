package com.mphasis.demoproject.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.demoproject.bo.ExamBo;
import com.mphasis.demoproject.bo.ScheduleBo;
import com.mphasis.demoproject.bo.UserBo;
import com.mphasis.demoproject.model.Exam;
import com.mphasis.demoproject.model.Schedule;
import com.mphasis.demoproject.model.User;

@Controller
public class FirstController {
	
	@Autowired
	UserBo ub;
	
	@Autowired
	ExamBo eb;
	
	@Autowired
	ScheduleBo sb;
	
	@RequestMapping("/userschedulestatus")
	public ModelAndView userScheduleStatus(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView("userschedulestatus");
		String mobile=req.getParameter("mobile");
		List<Schedule> li=sb.getScheduleByMobile(mobile);
		mv.addObject("li", li);
		return mv;
	}
	
	@RequestMapping("/adminviewconfirmedschedules")
	public ModelAndView confirmedSchedules() {
		ModelAndView mv=new ModelAndView("adminviewconfirmedschedules");
		List<Schedule> li=sb.getScheduleByStatus("Confirmed");
		mv.addObject("li", li);
		return mv;
	}
	@RequestMapping(value="checkTransaction", method=RequestMethod.POST)
	public ModelAndView checkTracnsactionSchedule(HttpServletRequest req) {
		ModelAndView mv=null;
		String tr1=req.getParameter("schtransaction");
		String tr2=req.getParameter("transactionno");
		int id=Integer.parseInt(req.getParameter("schid"));
		Schedule sch=sb.getScheduleById(id);
		if(tr1.equals(tr2)) {
			sch.setStatus("Confirmed");
		}
		else {
			sch.setStatus("Cancelled");
		}
		System.out.println(sch);
		sb.updateSchedule(sch);
		return mv;
	}
	@RequestMapping("/updateschedule")
	public ModelAndView updateSchedule(HttpServletRequest req) {
		int id=Integer.parseInt(req.getParameter("id"));
		
		
		Schedule sch=sb.getScheduleById(id);
		
		ModelAndView mv=new ModelAndView("updateschedulestatus");
		mv.addObject("sch", sch);
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout() {
		return new ModelAndView("index");
	}
	@RequestMapping("/adminviewrequestedschedules")
	public ModelAndView adminViewRequestedSchedule() {
		ModelAndView mv=new ModelAndView("adminviewrequestedschedules");
		List<Schedule> li=sb.getScheduleByStatus("Requested");
		mv.addObject("li", li);
		return mv;
	}
	
	@RequestMapping("/adminviewallschedules")
	public ModelAndView adminViewAllSchedule() {
		ModelAndView mv=new ModelAndView("adminviewallschedules");
		List<Schedule> li=sb.getAllSchedules();
		mv.addObject("li", li);
		return mv;
	}
	@RequestMapping(value="insertSchedule", method=RequestMethod.POST)
	public ModelAndView insertSchedule(HttpServletRequest req) {
		int exmid=Integer.parseInt(req.getParameter("eid"));
		String strDate=req.getParameter("dateofschedule");
		String mobile=req.getParameter("mobile");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dofsch=LocalDate.parse(strDate,formatter);
		LocalDate dofbook=LocalDate.now();
		String paymenttype=req.getParameter("paymenttype");
		String transaction=req.getParameter("transaction");
		String mobile2=req.getParameter("usermobile");
		Schedule s=null;
		if(mobile2.equals(mobile)) {
			s=new Schedule(0,exmid,mobile,dofbook,dofsch,paymenttype,transaction,"Requested",0);
		}
		else {
			s=new Schedule(0,exmid,mobile,dofbook,dofsch,paymenttype,transaction,"Cancelled",0);
		}
	 
		sb.insertSchedule(s);
		return new ModelAndView("userindex");
	}
	@RequestMapping(value="scheduleexam")
	public ModelAndView scheduleExam(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView("scheduleexam");
		int id=Integer.parseInt(req.getParameter("id"));
		Exam e=eb.getExamById(id);
		mv.addObject("e", e);
		return mv;
	}
	
	@RequestMapping("/userviewexams")
	public ModelAndView userViewExams() {
		ModelAndView mv=new ModelAndView("userviewexams");
		List<Exam> li=eb.getAllExams();
		mv.addObject("li", li);
		return mv;
	}
	
	@RequestMapping("/viewexams")
	public ModelAndView viewExams(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView("viewexams");
		List<Exam> li=eb.getAllExams();
		mv.addObject("li", li);
		return mv;
	}

	@RequestMapping(value="insertExam", method=RequestMethod.POST)
	public ModelAndView insertExam(HttpServletRequest req) {
		String examname=req.getParameter("ename");
		int eid=Integer.parseInt(req.getParameter("eid"));
		int noq=Integer.parseInt(req.getParameter("enoq"));
		int passmark=Integer.parseInt(req.getParameter("epassmark"));
		int dura=Integer.parseInt(req.getParameter("eduration"));
		double price=Double.parseDouble(req.getParameter("eprice"));
		String des=req.getParameter("edes");
		
		Exam e=new Exam(examname,eid,noq,passmark,des,price,dura);
		
		eb.insertExam(e);
		return new ModelAndView("success");
	}
	@RequestMapping("/")
	public ModelAndView firstMethod() {
		return new ModelAndView("index");
	}
	@RequestMapping("/register")
	public ModelAndView secondMethod() {
		return new ModelAndView("registration");
	}
	
	@RequestMapping(value="insertUser", method = RequestMethod.POST)
	public ModelAndView thirdMethod(HttpServletRequest req) {
		String name=req.getParameter("uname");
		String password=req.getParameter("upass");
		String mobile=req.getParameter("umobile");
		String mail=req.getParameter("umail");
		String gender=req.getParameter("ugender");
		String strDate=req.getParameter("udob");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		LocalDate dob=LocalDate.parse(strDate,formatter);
		String addr=req.getParameter("uaddr");
		String idproof=req.getParameter("uidname");
		String idvalue=req.getParameter("uidvalue");
		long l1=Long.parseLong(idvalue);
		String question=req.getParameter("uquestion");
		String answer=req.getParameter("uanswer");
		
		String utype="User";
		
		User u=new User(name,password,mobile,mail,addr,question,answer,dob,gender,idproof,l1,"User");
		System.out.println(u);
		
		ub.insertUser(u);
		// String securityQuestion,String answer, LocalDate dob, String gender, String idName, long idNumber, String userType
		return new ModelAndView("success");
	}
	
	@RequestMapping("/home")
	public ModelAndView foutmethod() {
		return new ModelAndView("index");
	}
	
	@RequestMapping("/login")
	public ModelAndView fiveMethod() {
		return new ModelAndView("login");
	}
	
	@RequestMapping(value="checkUser", method = RequestMethod.POST)
	public ModelAndView sixMethod(HttpServletRequest req) {
		ModelAndView mv=null;

		String value=req.getParameter("uvalue");
		String pass=req.getParameter("upass");
		
		String umobile="";
		String name="";
		List<User> li=ub.getAllUsers();
		if(value.equals("admin")) {
		if(pass.equals("admin")) {
			mv=new ModelAndView("adminindex");
		}
		else {
			mv=new ModelAndView("error");
		}
		}
		else {
		for(User u1:li) {
			if((u1.getMobile().equals(value)) || (u1.getEmail().equals(value)) ) {
				if(u1.getPassword().equals(pass)) {
					mv=new ModelAndView("userindex");
					name=u1.getName();
					umobile=u1.getMobile();
					break;
				}
				else {
					mv=new ModelAndView("error");
				}
			}
			else {
				mv=new ModelAndView("error");
			}
		
		}
		}
		mv.addObject("name", name);
		req.getSession().setAttribute("mobile", umobile);
		return mv;

	}
	
	@RequestMapping("/addexam")
	public ModelAndView addExam() {
		return new ModelAndView("addexam");
	}
	
	
}
