package com.mphasis.demoproject.bo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.mphasis.demoproject.model.Schedule;

@Repository
public class ScheduleBo {

SessionFactory sf=new Configuration().configure().buildSessionFactory();
	
	public boolean insertSchedule(Schedule sch) {
		//boolean b=false;
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		//s.save(e);
		s.persist(sch);
		//s.save(sch);
		t1.commit();
		s.close();
		
		return false;
	}
	public List<Schedule> getAllSchedules(){
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Schedule> li=s.createQuery("from Schedule").list();
		t1.commit();
		s.close();
		return li;
	//	t1.commit();
	
	}
	public List<Schedule> getScheduleByStatus(String value){
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
	
		@SuppressWarnings("deprecation")
		Criteria cr = s.createCriteria(Schedule.class);
		cr.add(Restrictions.eq("status", value));
		List<Schedule> results = cr.list();
		s.close();
		return results;
	}
	
	public List<Schedule> getScheduleByMobile(String value){
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
	
		@SuppressWarnings("deprecation")
		Criteria cr = s.createCriteria(Schedule.class);
		cr.add(Restrictions.eq("mobile", value));
		List<Schedule> results = cr.list();
		s.close();
		return results;
	}
	
	public Schedule getScheduleById(int id) {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		Schedule sch=s.get(Schedule.class, id);
		t1.commit();
		s.close();
		return sch;
	}
	public boolean updateSchedule(Schedule sch) {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		//s.save(e);
		s.merge(sch);
		//s.save(sch);
		t1.commit();
		s.close();
		
		return true;
	}
}
