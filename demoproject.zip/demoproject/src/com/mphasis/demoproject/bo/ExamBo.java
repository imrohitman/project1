package com.mphasis.demoproject.bo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.mphasis.demoproject.model.Exam;
@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class ExamBo {
	
SessionFactory sf=new Configuration().configure().buildSessionFactory();

   @CrossOrigin(origins = "http://localhost:4200")
	public boolean insertExam(Exam e) {
		//boolean b=false;
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		//s.save(e);
		s.persist(e);
		
		t1.commit();
		s.close();
		
		return false;
	}
	
	public List<Exam> getAllExams(){
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Exam> li=s.createQuery("from Exam").list();
		s.close();
		return li;
	}
	public Exam getExamById(int id) {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		Exam e=s.get(Exam.class, id);
		s.close();
		return e;
	}

}
