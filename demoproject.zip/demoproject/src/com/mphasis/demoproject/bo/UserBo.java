package com.mphasis.demoproject.bo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;


import com.mphasis.demoproject.model.User;


@Repository
public class UserBo {
	
SessionFactory sf=new Configuration().configure().buildSessionFactory();
	
	public boolean insertUser(User u) {
		//boolean b=false;
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		s.save(u);
		
		t1.commit();
		s.close();
		
		return false;
	}
	
	public List<User> getAllUsers(){
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<User> li=s.createQuery("from User").list();
		t1.commit();
		s.close();
		return li;
	
	}
	
	public User getUserByMobile(String value) {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		//User u=s.get(User.class, value);
		@SuppressWarnings("deprecation")
		Criteria cr = s.createCriteria(User.class);
		cr.add(Restrictions.eq("mobile", value));
		List<User> results = cr.list();
		User u=results.get(0);
		System.out.println(u);
		return u;
	
	}
	

}
