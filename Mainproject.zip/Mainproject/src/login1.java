

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


@WebServlet("/login1")
public class login1 extends HttpServlet {
	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		try {
			res.setContentType("text/html");
			PrintWriter pw = res.getWriter();

			String a = req.getParameter("t1");
			String b = req.getParameter("t2");
			
			System.out.println("hi");

			Configuration cfg = new Configuration();
			SessionFactory sf = cfg.configure().buildSessionFactory();
			Session ss = sf.openSession();
			mypojo pojo = new mypojo();
			pojo.setUsername(a);
			pojo.setPassword(b);
			Transaction tx = ss.beginTransaction();
			ss.save(pojo);
			tx.commit();
			ss.close();
			System.out.println("hiii");
			//res.sendRedirect("success.html");
		} catch (Exception ae) {
			
			ae.printStackTrace();
		}
		
		// TODO Auto-generated method stub
	}

}
